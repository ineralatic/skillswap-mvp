import { pgTable, text, varchar, integer, timestamp, decimal, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const roleEnum = pgEnum("role", ["USER", "MOD", "ADMIN"]);
export const visibilityEnum = pgEnum("visibility", ["PUBLIC", "LIMITED", "PRIVATE"]);
export const skillTypeEnum = pgEnum("skill_type", ["OFFERED", "WANTED"]);
export const modeEnum = pgEnum("mode", ["ONLINE", "OFFLINE"]);
export const sessionStatusEnum = pgEnum("session_status", ["SCHEDULED", "DONE", "CANCELED", "NO_SHOW"]);

export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  email: text("email").notNull().unique(),
  passHash: text("pass_hash").notNull(),
  role: roleEnum("role").default("USER").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const profiles = pgTable("profiles", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 36 }).notNull().unique().references(() => users.id),
  displayName: text("display_name"),
  bio: text("bio"),
  visibility: visibilityEnum("visibility").default("PUBLIC").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const skills = pgTable("skills", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: text("name").notNull().unique(),
  taxonomyTag: text("taxonomy_tag"),
});

export const profileSkills = pgTable("profile_skills", {
  id: varchar("id", { length: 36 }).primaryKey(),
  profileId: varchar("profile_id", { length: 36 }).notNull().references(() => profiles.id),
  skillId: varchar("skill_id", { length: 36 }).notNull().references(() => skills.id),
  level: integer("level").default(1),
  type: skillTypeEnum("type").notNull(),
});

export const availability = pgTable("availability", {
  id: varchar("id", { length: 36 }).primaryKey(),
  profileId: varchar("profile_id", { length: 36 }).notNull().references(() => profiles.id),
  weekday: integer("weekday").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  mode: modeEnum("mode").notNull(),
  zoneHint: text("zone_hint"),
});

export const sessions = pgTable("sessions", {
  id: varchar("id", { length: 36 }).primaryKey(),
  mentorProfileId: varchar("mentor_profile_id", { length: 36 }).notNull().references(() => profiles.id),
  learnerProfileId: varchar("learner_profile_id", { length: 36 }).notNull().references(() => profiles.id),
  start: timestamp("start").notNull(),
  end: timestamp("end").notNull(),
  location: text("location"),
  mode: modeEnum("mode").notNull(),
  note: text("note"),
  status: sessionStatusEnum("status").default("SCHEDULED").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const feedback = pgTable("feedback", {
  id: varchar("id", { length: 36 }).primaryKey(),
  sessionId: varchar("session_id", { length: 36 }).notNull().references(() => sessions.id),
  raterProfileId: varchar("rater_profile_id", { length: 36 }).notNull().references(() => profiles.id),
  targetProfileId: varchar("target_profile_id", { length: 36 }).notNull().references(() => profiles.id),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull(),
  comment: text("comment"),
  reliabilityScore: decimal("reliability_score", { precision: 3, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reputation = pgTable("reputation", {
  profileId: varchar("profile_id", { length: 36 }).primaryKey().references(() => profiles.id),
  ratingAvg: decimal("rating_avg", { precision: 2, scale: 1 }),
  ratingCount: integer("rating_count").default(0).notNull(),
  noShowRate: decimal("no_show_rate", { precision: 3, scale: 2 }),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ one }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
}));

export const profilesRelations = relations(profiles, ({ one, many }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
  skills: many(profileSkills),
  availability: many(availability),
  mentorSessions: many(sessions, { relationName: "mentorSessions" }),
  learnerSessions: many(sessions, { relationName: "learnerSessions" }),
  reputation: one(reputation, {
    fields: [profiles.id],
    references: [reputation.profileId],
  }),
}));

export const profileSkillsRelations = relations(profileSkills, ({ one }) => ({
  profile: one(profiles, {
    fields: [profileSkills.profileId],
    references: [profiles.id],
  }),
  skill: one(skills, {
    fields: [profileSkills.skillId],
    references: [skills.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertProfileSchema = createInsertSchema(profiles).omit({ id: true, createdAt: true });
export const insertSkillSchema = createInsertSchema(skills).omit({ id: true });
export const insertProfileSkillSchema = createInsertSchema(profileSkills).omit({ id: true });
export const insertAvailabilitySchema = createInsertSchema(availability).omit({ id: true });
export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, createdAt: true });
export const insertFeedbackSchema = createInsertSchema(feedback).omit({ id: true, createdAt: true });
export const insertReputationSchema = createInsertSchema(reputation).omit({ updatedAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type ProfileSkill = typeof profileSkills.$inferSelect;
export type InsertProfileSkill = z.infer<typeof insertProfileSkillSchema>;
export type Availability = typeof availability.$inferSelect;
export type InsertAvailability = z.infer<typeof insertAvailabilitySchema>;
export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Feedback = typeof feedback.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Reputation = typeof reputation.$inferSelect;
export type InsertReputation = z.infer<typeof insertReputationSchema>;

export const authRegisterSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const authLoginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const profileUpdateSchema = z.object({
  displayName: z.string().optional(),
  bio: z.string().optional(),
  visibility: z.enum(["PUBLIC", "LIMITED", "PRIVATE"]).optional(),
  offered: z.array(z.object({
    skillId: z.string(),
    level: z.number().min(1).max(5),
  })).optional(),
  wanted: z.array(z.object({
    skillId: z.string(),
  })).optional(),
  availability: z.array(z.object({
    weekday: z.number().min(1).max(7),
    startTime: z.string(),
    endTime: z.string(),
    mode: z.enum(["ONLINE", "OFFLINE"]),
    zoneHint: z.string().optional(),
  })).optional(),
});

export const scheduleSessionSchema = z.object({
  targetProfileId: z.string(),
  date: z.string(),
  from: z.string(),
  to: z.string(),
  mode: z.enum(["ONLINE", "OFFLINE"]),
  note: z.string().optional(),
  reminders: z.array(z.number()).optional(),
});

export type AuthRegister = z.infer<typeof authRegisterSchema>;
export type AuthLogin = z.infer<typeof authLoginSchema>;
export type ProfileUpdate = z.infer<typeof profileUpdateSchema>;
export type ScheduleSession = z.infer<typeof scheduleSessionSchema>;

export interface RecommendationResult {
  profileId: string;
  name: string;
  mode: "ONLINE" | "OFFLINE";
  reputation: {
    avg: number;
    count: number;
  };
  matchedSkills: string[];
  xai: string;
}

export interface ProfileWithDetails extends Profile {
  offeredSkills: (ProfileSkill & { skill: Skill })[];
  wantedSkills: (ProfileSkill & { skill: Skill })[];
  availability: Availability[];
  reputation: Reputation | null;
}

export interface UserWithProfile extends User {
  profile: ProfileWithDetails | null;
}
