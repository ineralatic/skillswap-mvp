import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface ReputationBadgeProps {
  avg: number;
  count: number;
  size?: "sm" | "md";
  className?: string;
}

export function ReputationBadge({
  avg,
  count,
  size = "md",
  className,
}: ReputationBadgeProps) {
  const displayRating = avg ? avg.toFixed(1) : "0.0";
  
  return (
    <div
      className={cn(
        "flex items-center gap-1.5",
        size === "sm" ? "text-xs" : "text-sm",
        className
      )}
      data-testid="reputation-badge"
    >
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={cn(
              size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5",
              star <= Math.round(avg)
                ? "fill-chart-4 text-chart-4"
                : "fill-muted text-muted"
            )}
          />
        ))}
      </div>
      <span className="font-medium">{displayRating}</span>
      <span className="text-muted-foreground">({count})</span>
    </div>
  );
}
