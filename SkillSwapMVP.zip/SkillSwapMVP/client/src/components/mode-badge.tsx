import { Globe, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface ModeBadgeProps {
  mode: "ONLINE" | "OFFLINE";
  className?: string;
}

export function ModeBadge({ mode, className }: ModeBadgeProps) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "gap-1.5 text-xs font-medium capitalize",
        mode === "ONLINE"
          ? "border-chart-2/30 bg-chart-2/10 text-chart-2"
          : "border-chart-5/30 bg-chart-5/10 text-chart-5",
        className
      )}
      data-testid={`badge-mode-${mode.toLowerCase()}`}
    >
      {mode === "ONLINE" ? (
        <Globe className="h-3 w-3" />
      ) : (
        <MapPin className="h-3 w-3" />
      )}
      {mode === "ONLINE" ? "Online" : "In-Person"}
    </Badge>
  );
}
