import { X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface SkillChipProps {
  name: string;
  level?: number;
  type?: "offered" | "wanted";
  onRemove?: () => void;
  className?: string;
}

export function SkillChip({
  name,
  level,
  type = "offered",
  onRemove,
  className,
}: SkillChipProps) {
  return (
    <Badge
      variant="secondary"
      className={cn(
        "gap-1.5 pl-3 pr-2 py-1.5 text-xs font-medium",
        type === "offered"
          ? "bg-primary/10 text-primary border-primary/20 hover:bg-primary/15"
          : "bg-accent text-accent-foreground border-accent/30 hover:bg-accent/80",
        className
      )}
    >
      <span>{name}</span>
      {level !== undefined && (
        <span className="flex items-center justify-center h-5 w-5 rounded-full bg-background/50 text-[10px] font-semibold">
          {level}
        </span>
      )}
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="ml-0.5 h-4 w-4 rounded-full hover:bg-background/50 flex items-center justify-center transition-colors"
          data-testid={`button-remove-skill-${name}`}
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </Badge>
  );
}

interface LevelSelectorProps {
  value: number;
  onChange: (level: number) => void;
}

export function LevelSelector({ value, onChange }: LevelSelectorProps) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((level) => (
        <button
          key={level}
          type="button"
          onClick={() => onChange(level)}
          className={cn(
            "h-6 w-6 rounded-full text-xs font-medium transition-all",
            level <= value
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground hover:bg-muted/80"
          )}
          data-testid={`button-level-${level}`}
        >
          {level}
        </button>
      ))}
    </div>
  );
}
