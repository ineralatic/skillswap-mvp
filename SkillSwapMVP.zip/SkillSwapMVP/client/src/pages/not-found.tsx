import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, ArrowLeft, Sparkles } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
      <Card className="max-w-md w-full border-border/50 bg-card/50 backdrop-blur-sm">
        <CardContent className="py-12 text-center space-y-6">
          <div className="relative">
            <div className="h-20 w-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
              <Sparkles className="h-10 w-10 text-primary" />
            </div>
            <div className="absolute -top-2 -right-2 h-8 w-8 rounded-full bg-destructive/10 flex items-center justify-center">
              <span className="text-lg font-bold text-destructive">?</span>
            </div>
          </div>

          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tight">404</h1>
            <p className="text-xl font-medium text-muted-foreground">
              Page Not Found
            </p>
          </div>

          <p className="text-muted-foreground leading-relaxed">
            The page you're looking for doesn't exist or has been moved.
            Let's get you back on track!
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
            <Link href="/">
              <Button className="w-full sm:w-auto gap-2" data-testid="button-go-home">
                <Home className="h-4 w-4" />
                Go Home
              </Button>
            </Link>
            <Button
              variant="outline"
              onClick={() => window.history.back()}
              className="gap-2"
              data-testid="button-go-back"
            >
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
