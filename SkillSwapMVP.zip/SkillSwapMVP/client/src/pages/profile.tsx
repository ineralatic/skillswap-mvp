import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/components/auth-context";
import { SkillChip, LevelSelector } from "@/components/skill-chip";
import { ProfileSkeleton } from "@/components/loading-skeleton";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Skill } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Save, Plus, X, Clock, Globe, MapPin, Loader2 } from "lucide-react";

const profileFormSchema = z.object({
  displayName: z.string().min(2, "Name must be at least 2 characters").max(50),
  bio: z.string().max(500).optional(),
  visibility: z.enum(["PUBLIC", "LIMITED", "PRIVATE"]),
});

type ProfileFormData = z.infer<typeof profileFormSchema>;

interface OfferedSkill {
  skillId: string;
  skillName: string;
  level: number;
}

interface WantedSkill {
  skillId: string;
  skillName: string;
}

interface AvailabilitySlot {
  id: string;
  weekday: number;
  startTime: string;
  endTime: string;
  mode: "ONLINE" | "OFFLINE";
  zoneHint?: string;
}

const weekdays = [
  { value: 1, label: "Monday" },
  { value: 2, label: "Tuesday" },
  { value: 3, label: "Wednesday" },
  { value: 4, label: "Thursday" },
  { value: 5, label: "Friday" },
  { value: 6, label: "Saturday" },
  { value: 7, label: "Sunday" },
];

const timeSlots = Array.from({ length: 24 }, (_, i) => {
  const hour = i.toString().padStart(2, "0");
  return { value: `${hour}:00`, label: `${hour}:00` };
});

export default function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const { toast } = useToast();

  const [offeredSkills, setOfferedSkills] = useState<OfferedSkill[]>([]);
  const [wantedSkills, setWantedSkills] = useState<WantedSkill[]>([]);
  const [availability, setAvailability] = useState<AvailabilitySlot[]>([]);
  const [selectedOfferedSkill, setSelectedOfferedSkill] = useState("");
  const [selectedWantedSkill, setSelectedWantedSkill] = useState("");

  const { data: skills, isLoading: skillsLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      displayName: "",
      bio: "",
      visibility: "PUBLIC",
    },
  });

  useEffect(() => {
    if (user?.profile) {
      form.reset({
        displayName: user.profile.displayName || "",
        bio: user.profile.bio || "",
        visibility: user.profile.visibility as "PUBLIC" | "LIMITED" | "PRIVATE",
      });

      if (user.profile.offeredSkills) {
        setOfferedSkills(
          user.profile.offeredSkills.map((ps) => ({
            skillId: ps.skillId,
            skillName: ps.skill.name,
            level: ps.level || 1,
          }))
        );
      }

      if (user.profile.wantedSkills) {
        setWantedSkills(
          user.profile.wantedSkills.map((ps) => ({
            skillId: ps.skillId,
            skillName: ps.skill.name,
          }))
        );
      }

      if (user.profile.availability) {
        setAvailability(
          user.profile.availability.map((a, i) => ({
            id: `slot-${i}`,
            weekday: a.weekday,
            startTime: a.startTime,
            endTime: a.endTime,
            mode: a.mode as "ONLINE" | "OFFLINE",
            zoneHint: a.zoneHint || undefined,
          }))
        );
      }
    }
  }, [user, form]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      return apiRequest("PUT", "/api/profile/me", {
        ...data,
        offered: offeredSkills.map((s) => ({
          skillId: s.skillId,
          level: s.level,
        })),
        wanted: wantedSkills.map((s) => ({
          skillId: s.skillId,
        })),
        availability: availability.map((a) => ({
          weekday: a.weekday,
          startTime: a.startTime,
          endTime: a.endTime,
          mode: a.mode,
          zoneHint: a.zoneHint,
        })),
      });
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile has been saved successfully.",
      });
      refreshUser();
      queryClient.invalidateQueries({ queryKey: ["/api/profile/me"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const addOfferedSkill = () => {
    if (!selectedOfferedSkill) return;
    const skill = skills?.find((s) => s.id === selectedOfferedSkill);
    if (skill && !offeredSkills.some((s) => s.skillId === skill.id)) {
      setOfferedSkills([
        ...offeredSkills,
        { skillId: skill.id, skillName: skill.name, level: 3 },
      ]);
    }
    setSelectedOfferedSkill("");
  };

  const addWantedSkill = () => {
    if (!selectedWantedSkill) return;
    const skill = skills?.find((s) => s.id === selectedWantedSkill);
    if (skill && !wantedSkills.some((s) => s.skillId === skill.id)) {
      setWantedSkills([
        ...wantedSkills,
        { skillId: skill.id, skillName: skill.name },
      ]);
    }
    setSelectedWantedSkill("");
  };

  const addAvailabilitySlot = () => {
    setAvailability([
      ...availability,
      {
        id: `slot-${Date.now()}`,
        weekday: 1,
        startTime: "09:00",
        endTime: "10:00",
        mode: "ONLINE",
      },
    ]);
  };

  const removeAvailabilitySlot = (id: string) => {
    setAvailability(availability.filter((a) => a.id !== id));
  };

  const updateAvailabilitySlot = (
    id: string,
    field: keyof AvailabilitySlot,
    value: string | number
  ) => {
    setAvailability(
      availability.map((a) =>
        a.id === id ? { ...a, [field]: value } : a
      )
    );
  };

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  const availableOfferedSkills = skills?.filter(
    (s) => !offeredSkills.some((os) => os.skillId === s.id)
  );

  const availableWantedSkills = skills?.filter(
    (s) =>
      !wantedSkills.some((ws) => ws.skillId === s.id) &&
      !offeredSkills.some((os) => os.skillId === s.id)
  );

  if (!user || skillsLoading) {
    return (
      <div className="max-w-2xl mx-auto py-8 px-4">
        <ProfileSkeleton />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-8 px-4 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">My Profile</h1>
        <p className="text-muted-foreground">
          Manage your skills, availability, and profile visibility
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Profile Information</CardTitle>
              <CardDescription>
                This is how other users will see you
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium text-muted-foreground">
                  Email
                </Label>
                <Input
                  value={user.email}
                  disabled
                  className="bg-muted/50"
                  data-testid="input-email-readonly"
                />
              </div>

              <FormField
                control={form.control}
                name="displayName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Display Name</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Your name"
                        data-testid="input-display-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bio</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Tell others about yourself..."
                        className="resize-none min-h-[100px]"
                        data-testid="input-bio"
                      />
                    </FormControl>
                    <FormDescription>
                      {field.value?.length || 0}/500 characters
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Skills I Can Teach</CardTitle>
              <CardDescription>
                Select the skills you can offer and rate your proficiency (1-5)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Select
                  value={selectedOfferedSkill}
                  onValueChange={setSelectedOfferedSkill}
                >
                  <SelectTrigger className="flex-1" data-testid="select-offered-skill">
                    <SelectValue placeholder="Select a skill to offer" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableOfferedSkills?.map((skill) => (
                      <SelectItem key={skill.id} value={skill.id}>
                        {skill.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  variant="secondary"
                  size="icon"
                  onClick={addOfferedSkill}
                  disabled={!selectedOfferedSkill}
                  data-testid="button-add-offered-skill"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {offeredSkills.length > 0 ? (
                <div className="space-y-3">
                  {offeredSkills.map((skill) => (
                    <div
                      key={skill.skillId}
                      className="flex items-center justify-between gap-4 p-3 rounded-lg bg-muted/30"
                    >
                      <SkillChip
                        name={skill.skillName}
                        type="offered"
                        onRemove={() =>
                          setOfferedSkills(
                            offeredSkills.filter((s) => s.skillId !== skill.skillId)
                          )
                        }
                      />
                      <LevelSelector
                        value={skill.level}
                        onChange={(level) =>
                          setOfferedSkills(
                            offeredSkills.map((s) =>
                              s.skillId === skill.skillId ? { ...s, level } : s
                            )
                          )
                        }
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No skills added yet. Select a skill above to get started.
                </p>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Skills I Want to Learn</CardTitle>
              <CardDescription>
                Select the skills you're interested in learning
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Select
                  value={selectedWantedSkill}
                  onValueChange={setSelectedWantedSkill}
                >
                  <SelectTrigger className="flex-1" data-testid="select-wanted-skill">
                    <SelectValue placeholder="Select a skill to learn" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableWantedSkills?.map((skill) => (
                      <SelectItem key={skill.id} value={skill.id}>
                        {skill.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  variant="secondary"
                  size="icon"
                  onClick={addWantedSkill}
                  disabled={!selectedWantedSkill}
                  data-testid="button-add-wanted-skill"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {wantedSkills.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {wantedSkills.map((skill) => (
                    <SkillChip
                      key={skill.skillId}
                      name={skill.skillName}
                      type="wanted"
                      onRemove={() =>
                        setWantedSkills(
                          wantedSkills.filter((s) => s.skillId !== skill.skillId)
                        )
                      }
                    />
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No skills added yet. Select skills you want to learn above.
                </p>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
              <div className="space-y-1">
                <CardTitle className="text-lg">Availability</CardTitle>
                <CardDescription>
                  Set your weekly availability for skill exchange sessions
                </CardDescription>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addAvailabilitySlot}
                className="gap-1"
                data-testid="button-add-availability"
              >
                <Plus className="h-4 w-4" />
                Add Slot
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {availability.length > 0 ? (
                <div className="space-y-3">
                  {availability.map((slot) => (
                    <div
                      key={slot.id}
                      className="grid gap-3 p-4 rounded-lg bg-muted/30 border border-border/30"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>Time Slot</span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeAvailabilitySlot(slot.id)}
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          data-testid={`button-remove-slot-${slot.id}`}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-4">
                        <Select
                          value={slot.weekday.toString()}
                          onValueChange={(v) =>
                            updateAvailabilitySlot(slot.id, "weekday", parseInt(v))
                          }
                        >
                          <SelectTrigger data-testid={`select-weekday-${slot.id}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {weekdays.map((day) => (
                              <SelectItem key={day.value} value={day.value.toString()}>
                                {day.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        <Select
                          value={slot.startTime}
                          onValueChange={(v) =>
                            updateAvailabilitySlot(slot.id, "startTime", v)
                          }
                        >
                          <SelectTrigger data-testid={`select-start-${slot.id}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time.value} value={time.value}>
                                {time.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        <Select
                          value={slot.endTime}
                          onValueChange={(v) =>
                            updateAvailabilitySlot(slot.id, "endTime", v)
                          }
                        >
                          <SelectTrigger data-testid={`select-end-${slot.id}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {timeSlots.map((time) => (
                              <SelectItem key={time.value} value={time.value}>
                                {time.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        <Select
                          value={slot.mode}
                          onValueChange={(v) =>
                            updateAvailabilitySlot(
                              slot.id,
                              "mode",
                              v as "ONLINE" | "OFFLINE"
                            )
                          }
                        >
                          <SelectTrigger data-testid={`select-mode-${slot.id}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ONLINE">
                              <div className="flex items-center gap-2">
                                <Globe className="h-4 w-4" />
                                Online
                              </div>
                            </SelectItem>
                            <SelectItem value="OFFLINE">
                              <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4" />
                                In-Person
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {slot.mode === "OFFLINE" && (
                        <Input
                          placeholder="Location / Zone (e.g., Downtown, North Campus)"
                          value={slot.zoneHint || ""}
                          onChange={(e) =>
                            updateAvailabilitySlot(slot.id, "zoneHint", e.target.value)
                          }
                          className="bg-background/50"
                          data-testid={`input-zone-${slot.id}`}
                        />
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 space-y-2">
                  <Clock className="h-8 w-8 text-muted-foreground mx-auto" />
                  <p className="text-sm text-muted-foreground">
                    No availability slots yet. Click "Add Slot" to set your schedule.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Profile Visibility</CardTitle>
              <CardDescription>
                Control who can see your profile and match with you
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="visibility"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <RadioGroup
                        value={field.value}
                        onValueChange={field.onChange}
                        className="space-y-3"
                      >
                        <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors">
                          <RadioGroupItem
                            value="PUBLIC"
                            id="public"
                            className="mt-0.5"
                            data-testid="radio-public"
                          />
                          <Label htmlFor="public" className="flex-1 cursor-pointer">
                            <div className="font-medium">Public</div>
                            <div className="text-sm text-muted-foreground">
                              Anyone can view your profile and request to connect
                            </div>
                          </Label>
                        </div>
                        <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors">
                          <RadioGroupItem
                            value="LIMITED"
                            id="limited"
                            className="mt-0.5"
                            data-testid="radio-limited"
                          />
                          <Label htmlFor="limited" className="flex-1 cursor-pointer">
                            <div className="font-medium">Limited</div>
                            <div className="text-sm text-muted-foreground">
                              Only users with matching skills can find you
                            </div>
                          </Label>
                        </div>
                        <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors">
                          <RadioGroupItem
                            value="PRIVATE"
                            id="private"
                            className="mt-0.5"
                            data-testid="radio-private"
                          />
                          <Label htmlFor="private" className="flex-1 cursor-pointer">
                            <div className="font-medium">Private</div>
                            <div className="text-sm text-muted-foreground">
                              Your profile is hidden from search and recommendations
                            </div>
                          </Label>
                        </div>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Button
            type="submit"
            className="w-full h-11"
            disabled={updateProfileMutation.isPending}
            data-testid="button-save-profile"
          >
            {updateProfileMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Profile
              </>
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
