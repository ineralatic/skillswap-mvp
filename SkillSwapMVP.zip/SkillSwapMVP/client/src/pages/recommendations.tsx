import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/components/auth-context";
import { ReputationBadge } from "@/components/reputation-badge";
import { ModeBadge } from "@/components/mode-badge";
import { SkillChip } from "@/components/skill-chip";
import { RecommendationsSkeleton } from "@/components/loading-skeleton";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { RecommendationResult } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Check,
  X,
  Filter,
  Globe,
  MapPin,
  Sunset,
  Sparkles,
  Users,
  Loader2,
} from "lucide-react";

type FilterOption = "all" | "online" | "offline" | "evenings";

export default function RecommendationsPage() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [activeFilters, setActiveFilters] = useState<FilterOption[]>([]);
  const [declinedIds, setDeclinedIds] = useState<Set<string>>(new Set());

  const {
    data: recommendations,
    isLoading,
    error,
  } = useQuery<RecommendationResult[]>({
    queryKey: ["/api/matching/top"],
    enabled: isAuthenticated,
  });

  const acceptMutation = useMutation({
    mutationFn: async (profileId: string) => {
      return apiRequest("POST", "/api/matching/accept", { profileId });
    },
    onSuccess: (_, profileId) => {
      setLocation(`/schedule?target=${profileId}`);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to accept match",
        variant: "destructive",
      });
    },
  });

  const toggleFilter = (filter: FilterOption) => {
    setActiveFilters((prev) => {
      if (filter === "all") {
        return [];
      }
      const withoutAll = prev.filter((f) => f !== "all");
      if (withoutAll.includes(filter)) {
        return withoutAll.filter((f) => f !== filter);
      }
      if (filter === "online") {
        return [...withoutAll.filter((f) => f !== "offline"), filter];
      }
      if (filter === "offline") {
        return [...withoutAll.filter((f) => f !== "online"), filter];
      }
      return [...withoutAll, filter];
    });
  };

  const handleDecline = (profileId: string) => {
    setDeclinedIds((prev) => new Set([...Array.from(prev), profileId]));
    toast({
      title: "Match declined",
      description: "This recommendation has been removed from your list.",
    });
  };

  const handleAccept = (profileId: string) => {
    acceptMutation.mutate(profileId);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const filteredRecommendations = recommendations?.filter((rec) => {
    if (declinedIds.has(rec.profileId)) return false;

    if (activeFilters.length === 0) return true;

    if (activeFilters.includes("online") && rec.mode !== "ONLINE") return false;
    if (activeFilters.includes("offline") && rec.mode !== "OFFLINE") return false;

    return true;
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4">
        <Card className="border-border/50 bg-card/50">
          <CardContent className="py-16 text-center space-y-4">
            <Users className="h-12 w-12 text-muted-foreground mx-auto" />
            <h2 className="text-xl font-semibold">Sign in to View Matches</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Create an account or sign in to see personalized skill exchange
              recommendations.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-8 px-4">
        <RecommendationsSkeleton />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4">
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="py-8 text-center space-y-4">
            <p className="text-destructive font-medium">
              Failed to load recommendations
            </p>
            <Button
              variant="outline"
              onClick={() =>
                queryClient.invalidateQueries({ queryKey: ["/api/matching/top"] })
              }
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <Sparkles className="h-8 w-8 text-primary" />
          Your Matches
        </h1>
        <p className="text-muted-foreground">
          AI-powered recommendations based on your skills and preferences
        </p>
      </div>

      <Card className="sticky top-20 z-40 border-border/50 bg-card/80 backdrop-blur-xl">
        <CardContent className="py-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground mr-2">
              Filters:
            </span>
            <Badge
              variant={activeFilters.length === 0 ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => toggleFilter("all")}
              data-testid="filter-all"
            >
              All
            </Badge>
            <Badge
              variant={activeFilters.includes("online") ? "default" : "outline"}
              className="cursor-pointer gap-1"
              onClick={() => toggleFilter("online")}
              data-testid="filter-online"
            >
              <Globe className="h-3 w-3" />
              Online Only
            </Badge>
            <Badge
              variant={activeFilters.includes("offline") ? "default" : "outline"}
              className="cursor-pointer gap-1"
              onClick={() => toggleFilter("offline")}
              data-testid="filter-offline"
            >
              <MapPin className="h-3 w-3" />
              In-Person
            </Badge>
            <Badge
              variant={activeFilters.includes("evenings") ? "default" : "outline"}
              className="cursor-pointer gap-1"
              onClick={() => toggleFilter("evenings")}
              data-testid="filter-evenings"
            >
              <Sunset className="h-3 w-3" />
              Evenings
            </Badge>
          </div>
        </CardContent>
      </Card>

      {filteredRecommendations && filteredRecommendations.length > 0 ? (
        <div className="grid gap-4 md:grid-cols-2">
          {filteredRecommendations.map((rec) => (
            <Card
              key={rec.profileId}
              className="overflow-hidden border-border/50 hover-elevate group"
              data-testid={`card-recommendation-${rec.profileId}`}
            >
              <CardContent className="p-6 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-12 w-12 border-2 border-primary/20">
                      <AvatarFallback className="bg-primary/10 text-primary font-medium">
                        {getInitials(rec.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-1">
                      <h3 className="font-semibold text-lg leading-tight">
                        {rec.name}
                      </h3>
                      <ReputationBadge
                        avg={rec.reputation.avg}
                        count={rec.reputation.count}
                        size="sm"
                      />
                    </div>
                  </div>
                  <ModeBadge mode={rec.mode} />
                </div>

                {rec.matchedSkills && rec.matchedSkills.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {rec.matchedSkills.slice(0, 3).map((skill) => (
                      <SkillChip key={skill} name={skill} type="offered" />
                    ))}
                  </div>
                )}

                <div className="border-l-2 border-primary/30 pl-3 py-1">
                  <p
                    className="text-sm text-muted-foreground italic leading-relaxed"
                    data-testid={`xai-${rec.profileId}`}
                  >
                    {rec.xai}
                  </p>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    className="flex-1 gap-2"
                    onClick={() => handleAccept(rec.profileId)}
                    disabled={acceptMutation.isPending}
                    data-testid={`button-accept-${rec.profileId}`}
                  >
                    {acceptMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Check className="h-4 w-4" />
                        Accept
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 gap-2"
                    onClick={() => handleDecline(rec.profileId)}
                    data-testid={`button-decline-${rec.profileId}`}
                  >
                    <X className="h-4 w-4" />
                    Decline
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="border-border/50 bg-card/50">
          <CardContent className="py-16 text-center space-y-4">
            <div className="h-16 w-16 rounded-2xl bg-muted/50 flex items-center justify-center mx-auto">
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold">No Matches Found</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              {declinedIds.size > 0
                ? "You've reviewed all available matches. Check back later for new recommendations!"
                : "Complete your profile with skills and availability to receive personalized recommendations."}
            </p>
            <Button
              variant="outline"
              onClick={() =>
                queryClient.invalidateQueries({ queryKey: ["/api/matching/top"] })
              }
              data-testid="button-refresh-matches"
            >
              Refresh Matches
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
