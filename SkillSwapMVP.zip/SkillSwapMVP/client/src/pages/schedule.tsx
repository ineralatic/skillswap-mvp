import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { useAuth } from "@/components/auth-context";
import { ModeBadge } from "@/components/mode-badge";
import { ScheduleSkeleton } from "@/components/loading-skeleton";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { RecommendationResult } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Calendar,
  Clock,
  Globe,
  MapPin,
  Bell,
  CheckCircle2,
  Loader2,
  ArrowRight,
} from "lucide-react";

const scheduleFormSchema = z.object({
  date: z.string().min(1, "Please select a date"),
  from: z.string().min(1, "Please select a start time"),
  to: z.string().min(1, "Please select an end time"),
  mode: z.enum(["ONLINE", "OFFLINE"]),
  note: z.string().max(500).optional(),
  reminder24h: z.boolean().default(true),
  reminder2h: z.boolean().default(true),
});

type ScheduleFormData = z.infer<typeof scheduleFormSchema>;

const timeSlots = Array.from({ length: 24 }, (_, i) => {
  const hour = i.toString().padStart(2, "0");
  return { value: `${hour}:00`, label: `${hour}:00` };
});

export default function SchedulePage() {
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const targetProfileId = params.get("target");
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [isScheduled, setIsScheduled] = useState(false);
  const [sessionDetails, setSessionDetails] = useState<{
    sessionId: string;
    date: string;
    time: string;
  } | null>(null);

  const { data: targetProfile, isLoading: profileLoading } =
    useQuery<RecommendationResult>({
      queryKey: ["/api/profile", targetProfileId],
      enabled: !!targetProfileId && isAuthenticated,
    });

  const form = useForm<ScheduleFormData>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      date: "",
      from: "09:00",
      to: "10:00",
      mode: "ONLINE",
      note: "",
      reminder24h: true,
      reminder2h: true,
    },
  });

  const scheduleMutation = useMutation({
    mutationFn: async (data: ScheduleFormData): Promise<{ ok: boolean; sessionId: string }> => {
      const reminders: number[] = [];
      if (data.reminder24h) reminders.push(24);
      if (data.reminder2h) reminders.push(2);

      return apiRequest<{ ok: boolean; sessionId: string }>("POST", "/api/schedule", {
        targetProfileId: targetProfileId,
        date: data.date,
        from: data.from,
        to: data.to,
        mode: data.mode,
        note: data.note,
        reminders,
      });
    },
    onSuccess: (response) => {
      const formData = form.getValues();
      setSessionDetails({
        sessionId: response.sessionId,
        date: formData.date,
        time: `${formData.from} - ${formData.to}`,
      });
      setIsScheduled(true);
      toast({
        title: "Session scheduled!",
        description: "Your skill exchange session has been confirmed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to schedule session",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ScheduleFormData) => {
    scheduleMutation.mutate(data);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const minDate = new Date().toISOString().split("T")[0];

  if (!isAuthenticated) {
    return (
      <div className="max-w-lg mx-auto py-12 px-4">
        <Card className="border-border/50 bg-card/50">
          <CardContent className="py-16 text-center space-y-4">
            <Calendar className="h-12 w-12 text-muted-foreground mx-auto" />
            <h2 className="text-xl font-semibold">Sign in to Schedule</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Create an account or sign in to schedule skill exchange sessions.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!targetProfileId) {
    return (
      <div className="max-w-lg mx-auto py-12 px-4">
        <Card className="border-border/50 bg-card/50">
          <CardContent className="py-16 text-center space-y-4">
            <Calendar className="h-12 w-12 text-muted-foreground mx-auto" />
            <h2 className="text-xl font-semibold">No Partner Selected</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Accept a match from your recommendations to schedule a session.
            </p>
            <Button onClick={() => setLocation("/recommendations")} data-testid="button-go-to-recommendations">
              View Recommendations
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (profileLoading) {
    return (
      <div className="max-w-lg mx-auto py-8 px-4">
        <ScheduleSkeleton />
      </div>
    );
  }

  if (isScheduled && sessionDetails) {
    return (
      <div className="max-w-lg mx-auto py-12 px-4">
        <Card className="border-border/50 overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-primary to-chart-2" />
          <CardContent className="py-12 text-center space-y-6">
            <div className="h-16 w-16 rounded-full bg-chart-2/10 flex items-center justify-center mx-auto">
              <CheckCircle2 className="h-8 w-8 text-chart-2" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Session Scheduled!</h2>
              <p className="text-muted-foreground">
                Your skill exchange session has been confirmed
              </p>
            </div>

            <Card className="bg-muted/30 border-border/50">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Date</span>
                  <span className="font-medium">{sessionDetails.date}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Time</span>
                  <span className="font-medium">{sessionDetails.time}</span>
                </div>
                {targetProfile && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Partner</span>
                    <span className="font-medium">{targetProfile.name}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Session ID
                  </span>
                  <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                    {sessionDetails.sessionId.slice(0, 8)}
                  </code>
                </div>
              </CardContent>
            </Card>

            <div className="flex flex-col gap-3 pt-4">
              <Button onClick={() => setLocation("/recommendations")} data-testid="button-back-to-matches">
                Back to Matches
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setIsScheduled(false);
                  form.reset();
                }}
                data-testid="button-schedule-another"
              >
                Schedule Another Session
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto py-8 px-4 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <Calendar className="h-8 w-8 text-primary" />
          Schedule Session
        </h1>
        <p className="text-muted-foreground">
          Set up your skill exchange session details
        </p>
      </div>

      {targetProfile && (
        <Card className="border-border/50 bg-muted/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12 border-2 border-primary/20">
                <AvatarFallback className="bg-primary/10 text-primary font-medium">
                  {getInitials(targetProfile.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">
                  Scheduling with
                </p>
                <p className="font-semibold">{targetProfile.name}</p>
              </div>
              <ModeBadge mode={targetProfile.mode} />
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Session Details</CardTitle>
          <CardDescription>
            Choose a date and time that works for you
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      Date
                    </FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="date"
                        min={minDate}
                        className="bg-background/50"
                        data-testid="input-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="from"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        From
                      </FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-from-time">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {timeSlots.map((time) => (
                            <SelectItem key={time.value} value={time.value}>
                              {time.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="to"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        To
                      </FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-to-time">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {timeSlots.map((time) => (
                            <SelectItem key={time.value} value={time.value}>
                              {time.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="mode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Session Mode</FormLabel>
                    <FormControl>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/30">
                        <div className="flex items-center gap-3">
                          {field.value === "ONLINE" ? (
                            <Globe className="h-5 w-5 text-chart-2" />
                          ) : (
                            <MapPin className="h-5 w-5 text-chart-5" />
                          )}
                          <div>
                            <p className="font-medium">
                              {field.value === "ONLINE"
                                ? "Online"
                                : "In-Person"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {field.value === "ONLINE"
                                ? "Video call or screen share"
                                : "Meet at a physical location"}
                            </p>
                          </div>
                        </div>
                        <Switch
                          checked={field.value === "ONLINE"}
                          onCheckedChange={(checked) =>
                            field.onChange(checked ? "ONLINE" : "OFFLINE")
                          }
                          data-testid="switch-mode"
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="note"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Note (optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Any specific topics or questions you'd like to cover..."
                        className="resize-none min-h-[80px]"
                        data-testid="input-note"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-3">
                <Label className="flex items-center gap-2 text-sm font-medium">
                  <Bell className="h-4 w-4 text-muted-foreground" />
                  Reminders
                </Label>
                <div className="flex gap-6">
                  <FormField
                    control={form.control}
                    name="reminder24h"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-2 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-reminder-24h"
                          />
                        </FormControl>
                        <Label className="text-sm font-normal cursor-pointer">
                          24 hours before
                        </Label>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="reminder2h"
                    render={({ field }) => (
                      <FormItem className="flex items-center gap-2 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-reminder-2h"
                          />
                        </FormControl>
                        <Label className="text-sm font-normal cursor-pointer">
                          2 hours before
                        </Label>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-11"
                disabled={scheduleMutation.isPending}
                data-testid="button-confirm-schedule"
              >
                {scheduleMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <CheckCircle2 className="mr-2 h-4 w-4" />
                    Confirm Session
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
