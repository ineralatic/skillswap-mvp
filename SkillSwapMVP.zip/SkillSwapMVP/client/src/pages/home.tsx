import { Link } from "wouter";
import { useAuth } from "@/components/auth-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Sparkles,
  Users,
  Calendar,
  ArrowRight,
  Zap,
  Brain,
  Clock,
} from "lucide-react";

export default function HomePage() {
  const { isAuthenticated } = useAuth();

  const features = [
    {
      icon: Brain,
      title: "Smart Matching",
      description:
        "Our AI-powered algorithm finds the perfect skill exchange partners based on your interests and availability.",
    },
    {
      icon: Users,
      title: "Peer-to-Peer Learning",
      description:
        "Connect directly with people who have the skills you want to learn, and teach what you know best.",
    },
    {
      icon: Clock,
      title: "Flexible Scheduling",
      description:
        "Set your availability and let the system find overlapping time slots that work for both parties.",
    },
    {
      icon: Zap,
      title: "Instant Recommendations",
      description:
        "Get personalized Top-5 matches with clear explanations of why each person is a great fit.",
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="absolute top-20 left-10 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute bottom-10 right-10 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />

        <div className="relative max-w-4xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
            <Sparkles className="h-4 w-4" />
            <span>AI-Powered Skill Matching</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight">
            Exchange Skills,{" "}
            <span className="bg-gradient-to-r from-primary to-chart-3 bg-clip-text text-transparent">
              Grow Together
            </span>
          </h1>

          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            SkillSwap connects you with peers who want to learn what you know
            and can teach what you want to learn. No money needed—just your
            time and expertise.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/recommendations">
                  <Button size="lg" className="gap-2 h-12 px-6" data-testid="button-find-matches">
                    <Users className="h-5 w-5" />
                    Find Matches
                  </Button>
                </Link>
                <Link href="/profile">
                  <Button variant="outline" size="lg" className="gap-2 h-12 px-6" data-testid="button-edit-profile">
                    Edit Profile
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </>
            ) : (
              <>
                <Button size="lg" className="gap-2 h-12 px-6" data-testid="button-get-started">
                  Get Started Free
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="lg" className="gap-2 h-12 px-6">
                  Learn More
                </Button>
              </>
            )}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our intelligent matching system makes skill exchange simple and
              effective
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="group border-border/50 bg-card/50 backdrop-blur-sm hover-elevate"
              >
                <CardContent className="p-6 space-y-4">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden border-border/50 bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="p-8 sm:p-12 text-center space-y-6">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-primary/10 mx-auto">
                <Calendar className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Ready to Start Learning?
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto">
                Create your profile, add your skills, and get matched with your
                first learning partner in minutes.
              </p>
              {isAuthenticated ? (
                <Link href="/recommendations">
                  <Button size="lg" className="gap-2" data-testid="button-view-recommendations">
                    View Recommendations
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              ) : (
                <Button size="lg" className="gap-2" data-testid="button-create-account">
                  Create Free Account
                  <ArrowRight className="h-4 w-4" />
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
