const synonymsMap: Record<string, string[]> = {
  "python": ["python basics", "intro to python", "python programming", "python fundamentals"],
  "javascript": ["javascript basics", "intro to javascript", "js fundamentals", "web development js"],
  "react": ["react.js", "reactjs", "react basics", "frontend react"],
  "data": ["data analysis", "data science", "data visualization", "analytics"],
  "excel": ["excel basics", "excel pivot", "spreadsheets", "microsoft excel"],
  "jupyter": ["jupyter notebook", "jupyter/colab intro", "colab", "notebooks"],
  "machine learning": ["ml basics", "machine learning intro", "ai/ml", "deep learning basics"],
  "sql": ["sql basics", "database queries", "sql programming", "relational databases"],
  "git": ["git basics", "version control", "github", "source control"],
  "design": ["ui design", "ux design", "graphic design", "web design"],
};

function normalizeSkillName(name: string): string {
  return name.toLowerCase().trim();
}

export function getSkillSynonyms(skillName: string): string[] {
  const normalized = normalizeSkillName(skillName);
  const result: string[] = [normalized];
  
  for (const [key, synonyms] of Object.entries(synonymsMap)) {
    if (normalized.includes(key) || synonyms.some(s => normalized.includes(s))) {
      result.push(key, ...synonyms);
    }
  }
  
  return Array.from(new Set(result));
}

function trigramSimilarity(a: string, b: string): number {
  const getTrigrams = (s: string): Set<string> => {
    const padded = `  ${s.toLowerCase()}  `;
    const trigrams = new Set<string>();
    for (let i = 0; i < padded.length - 2; i++) {
      trigrams.add(padded.slice(i, i + 3));
    }
    return trigrams;
  };

  const trigramsA = getTrigrams(a);
  const trigramsB = getTrigrams(b);

  const arrA = Array.from(trigramsA);
  const arrB = Array.from(trigramsB);
  const intersection = new Set(arrA.filter(x => trigramsB.has(x)));
  const union = new Set([...arrA, ...arrB]);

  return intersection.size / union.size;
}

export function fuzzyMatch(skill1: string, skill2: string): number {
  const norm1 = normalizeSkillName(skill1);
  const norm2 = normalizeSkillName(skill2);
  
  if (norm1 === norm2) return 1.0;
  
  const synonyms1 = getSkillSynonyms(skill1);
  const synonyms2 = getSkillSynonyms(skill2);
  
  for (const s1 of synonyms1) {
    for (const s2 of synonyms2) {
      if (s1 === s2) return 0.95;
    }
  }
  
  return trigramSimilarity(norm1, norm2);
}

export function skillNameToVector(name: string): number[] {
  const normalized = normalizeSkillName(name);
  const vector: number[] = [];
  
  for (let i = 0; i < 8; i++) {
    let hash = 0;
    const chars = normalized + String(i);
    for (let j = 0; j < chars.length; j++) {
      const char = chars.charCodeAt(j);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    vector.push((Math.abs(hash) % 1000) / 1000);
  }
  
  return vector;
}

export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  
  const magnitude = Math.sqrt(normA) * Math.sqrt(normB);
  return magnitude === 0 ? 0 : dotProduct / magnitude;
}
