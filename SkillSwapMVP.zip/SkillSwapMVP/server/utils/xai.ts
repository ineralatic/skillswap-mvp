interface XAISignals {
  matchedSkills: string[];
  overlappingSlot?: { weekday: number; time: string };
  reputation: { avg: number; count: number };
  similarity: number;
  freshness?: number;
}

const weekdayNames = ["", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export function generateXAIExplanation(signals: XAISignals): string {
  const parts: string[] = [];

  if (signals.matchedSkills.length > 0) {
    const skillsText = signals.matchedSkills.slice(0, 2).join(", ");
    parts.push(`Match: ${skillsText}`);
  }

  if (signals.overlappingSlot) {
    const dayName = weekdayNames[signals.overlappingSlot.weekday] || "Day";
    parts.push(`slot ${dayName} ${signals.overlappingSlot.time}`);
  }

  if (signals.reputation.count > 0) {
    const avgStr = signals.reputation.avg.toFixed(1);
    parts.push(`reputation ${avgStr}/5 (${signals.reputation.count})`);
  } else {
    parts.push("new user");
  }

  if (signals.similarity >= 0.9) {
    parts.push("excellent skill match");
  } else if (signals.similarity >= 0.75) {
    parts.push("good skill match");
  }

  return parts.join("; ");
}

export function calculateMatchScore(signals: {
  similarity: number;
  timeOverlap: number;
  repScore: number;
  freshness: number;
  fairnessPenalty: number;
}): number {
  return (
    0.5 * signals.similarity +
    0.2 * signals.timeOverlap +
    0.2 * signals.repScore +
    0.05 * signals.freshness -
    0.05 * signals.fairnessPenalty
  );
}

export function normalizeReputationScore(avg: number | null, count: number): number {
  if (!avg || count === 0) return 0.5;
  
  const normalizedAvg = (avg - 1) / 4;
  
  const countWeight = Math.min(count / 10, 1);
  
  return normalizedAvg * 0.7 + countWeight * 0.3;
}
