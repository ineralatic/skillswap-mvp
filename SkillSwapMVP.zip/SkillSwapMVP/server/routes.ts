import type { Express } from "express";
import { createServer, type Server } from "http";
import bcrypt from "bcrypt";
import cookieParser from "cookie-parser";
import { storage } from "./storage";
import { authMiddleware, signToken, optionalAuthMiddleware } from "./middleware/auth";
import { seedDatabase } from "./seed";
import {
  authRegisterSchema,
  authLoginSchema,
  profileUpdateSchema,
  scheduleSessionSchema,
} from "@shared/schema";
import type { RecommendationResult, ProfileWithDetails } from "@shared/schema";
import {
  fuzzyMatch,
  skillNameToVector,
  cosineSimilarity,
} from "./utils/fuzzy";
import {
  generateXAIExplanation,
  calculateMatchScore,
  normalizeReputationScore,
} from "./utils/xai";

let seeded = false;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.use(cookieParser());

  if (!seeded) {
    seeded = true;
    try {
      await seedDatabase();
    } catch (error) {
      console.error("Error seeding database:", error);
    }
  }

  app.post("/api/auth/register", async (req, res) => {
    try {
      const parsed = authRegisterSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ ok: false, error: parsed.error.errors[0].message });
      }

      const { email, password } = parsed.data;

      const existing = await storage.getUserByEmail(email);
      if (existing) {
        return res.status(400).json({ ok: false, error: "Email already registered" });
      }

      const passHash = await bcrypt.hash(password, 10);
      const user = await storage.createUser({ email, passHash, role: "USER" });

      await storage.createProfile({
        userId: user.id,
        displayName: email.split("@")[0],
        bio: null,
        visibility: "PUBLIC",
      });

      const token = signToken({ id: user.id, email: user.email, role: user.role });
      
      res.cookie("token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 24 * 60 * 60 * 1000,
      });

      res.status(201).json({ ok: true });
    } catch (error) {
      console.error("Register error:", error);
      res.status(500).json({ ok: false, error: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const parsed = authLoginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ ok: false, error: parsed.error.errors[0].message });
      }

      const { email, password } = parsed.data;

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ ok: false, error: "Invalid email or password" });
      }

      const valid = await bcrypt.compare(password, user.passHash);
      if (!valid) {
        return res.status(401).json({ ok: false, error: "Invalid email or password" });
      }

      const token = signToken({ id: user.id, email: user.email, role: user.role });

      res.cookie("token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 24 * 60 * 60 * 1000,
      });

      res.json({ ok: true });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ ok: false, error: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (_req, res) => {
    res.clearCookie("token");
    res.json({ ok: true });
  });

  app.get("/api/auth/me", authMiddleware, async (req, res) => {
    try {
      const userWithProfile = await storage.getUserWithProfile(req.user!.id);
      if (!userWithProfile) {
        return res.status(404).json({ ok: false, error: "User not found" });
      }

      const { passHash, ...safeUser } = userWithProfile;
      res.json({ user: safeUser });
    } catch (error) {
      console.error("Get me error:", error);
      res.status(500).json({ ok: false, error: "Failed to fetch user" });
    }
  });

  app.get("/api/skills", async (_req, res) => {
    try {
      const skills = await storage.getAllSkills();
      res.json(skills);
    } catch (error) {
      console.error("Get skills error:", error);
      res.status(500).json({ ok: false, error: "Failed to fetch skills" });
    }
  });

  app.get("/api/profile/me", authMiddleware, async (req, res) => {
    try {
      const profile = await storage.getProfileByUserId(req.user!.id);
      if (!profile) {
        return res.status(404).json({ ok: false, error: "Profile not found" });
      }

      const profileWithDetails = await storage.getProfileWithDetails(profile.id);
      res.json(profileWithDetails);
    } catch (error) {
      console.error("Get profile error:", error);
      res.status(500).json({ ok: false, error: "Failed to fetch profile" });
    }
  });

  app.put("/api/profile/me", authMiddleware, async (req, res) => {
    try {
      const parsed = profileUpdateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ ok: false, error: parsed.error.errors[0].message });
      }

      const profile = await storage.getProfileByUserId(req.user!.id);
      if (!profile) {
        return res.status(404).json({ ok: false, error: "Profile not found" });
      }

      const { offered, wanted, availability, ...profileData } = parsed.data;

      if (Object.keys(profileData).length > 0) {
        await storage.updateProfile(profile.id, profileData);
      }

      if (offered !== undefined) {
        await storage.deleteProfileSkills(profile.id, "OFFERED");
        for (const skill of offered) {
          await storage.createProfileSkill({
            profileId: profile.id,
            skillId: skill.skillId,
            level: skill.level,
            type: "OFFERED",
          });
        }
      }

      if (wanted !== undefined) {
        await storage.deleteProfileSkills(profile.id, "WANTED");
        for (const skill of wanted) {
          await storage.createProfileSkill({
            profileId: profile.id,
            skillId: skill.skillId,
            level: 1,
            type: "WANTED",
          });
        }
      }

      if (availability !== undefined) {
        await storage.deleteAvailability(profile.id);
        for (const slot of availability) {
          await storage.createAvailability({
            profileId: profile.id,
            weekday: slot.weekday,
            startTime: slot.startTime,
            endTime: slot.endTime,
            mode: slot.mode,
            zoneHint: slot.zoneHint,
          });
        }
      }

      res.json({ ok: true });
    } catch (error) {
      console.error("Update profile error:", error);
      res.status(500).json({ ok: false, error: "Failed to update profile" });
    }
  });

  app.get("/api/profile/:profileId", optionalAuthMiddleware, async (req, res) => {
    try {
      const profileWithDetails = await storage.getProfileWithDetails(req.params.profileId);
      if (!profileWithDetails) {
        return res.status(404).json({ ok: false, error: "Profile not found" });
      }

      const result: RecommendationResult = {
        profileId: profileWithDetails.id,
        name: profileWithDetails.displayName || "User",
        mode: profileWithDetails.availability?.[0]?.mode || "ONLINE",
        reputation: {
          avg: profileWithDetails.reputation?.ratingAvg
            ? parseFloat(profileWithDetails.reputation.ratingAvg)
            : 0,
          count: profileWithDetails.reputation?.ratingCount || 0,
        },
        matchedSkills: profileWithDetails.offeredSkills?.map((s) => s.skill.name) || [],
        xai: "",
      };

      res.json(result);
    } catch (error) {
      console.error("Get profile error:", error);
      res.status(500).json({ ok: false, error: "Failed to fetch profile" });
    }
  });

  app.get("/api/matching/top", authMiddleware, async (req, res) => {
    try {
      const userProfile = await storage.getProfileByUserId(req.user!.id);
      if (!userProfile) {
        return res.status(404).json({ ok: false, error: "Profile not found" });
      }

      const myProfile = await storage.getProfileWithDetails(userProfile.id);
      if (!myProfile) {
        return res.status(404).json({ ok: false, error: "Profile details not found" });
      }

      const candidates = await storage.getProfilesForMatching(userProfile.id);

      if (candidates.length === 0) {
        return res.json([]);
      }

      const myWantedSkills = myProfile.wantedSkills || [];
      const myAvailability = myProfile.availability || [];

      const myWantedVectors = myWantedSkills.map((ws) => ({
        name: ws.skill.name,
        vector: skillNameToVector(ws.skill.name),
      }));

      const scoredCandidates: {
        profile: ProfileWithDetails;
        score: number;
        matchedSkills: string[];
        overlappingSlot?: { weekday: number; time: string };
        similarity: number;
      }[] = [];

      for (const candidate of candidates) {
        const offeredSkills = candidate.offeredSkills || [];
        const candidateAvailability = candidate.availability || [];

        let bestSimilarity = 0;
        const matchedSkills: string[] = [];

        for (const wanted of myWantedVectors) {
          for (const offered of offeredSkills) {
            const offeredVector = skillNameToVector(offered.skill.name);
            const cosSim = cosineSimilarity(wanted.vector, offeredVector);
            const fuzzySim = fuzzyMatch(wanted.name, offered.skill.name);
            const combinedSim = Math.max(cosSim, fuzzySim);

            if (combinedSim >= 0.75) {
              matchedSkills.push(offered.skill.name);
              bestSimilarity = Math.max(bestSimilarity, combinedSim);
            }
          }
        }

        if (matchedSkills.length === 0) {
          for (const offered of offeredSkills) {
            for (const wanted of myWantedSkills) {
              const sim = fuzzyMatch(wanted.skill.name, offered.skill.name);
              if (sim >= 0.5) {
                matchedSkills.push(offered.skill.name);
                bestSimilarity = Math.max(bestSimilarity, sim);
              }
            }
          }
        }

        let overlappingSlot: { weekday: number; time: string } | undefined;
        let timeOverlap = 0;

        for (const mySlot of myAvailability) {
          for (const theirSlot of candidateAvailability) {
            if (mySlot.weekday === theirSlot.weekday) {
              const myStart = parseInt(mySlot.startTime.split(":")[0]);
              const myEnd = parseInt(mySlot.endTime.split(":")[0]);
              const theirStart = parseInt(theirSlot.startTime.split(":")[0]);
              const theirEnd = parseInt(theirSlot.endTime.split(":")[0]);

              const overlapStart = Math.max(myStart, theirStart);
              const overlapEnd = Math.min(myEnd, theirEnd);

              if (overlapEnd > overlapStart) {
                timeOverlap = 1;
                overlappingSlot = {
                  weekday: mySlot.weekday,
                  time: `${overlapStart}:00–${overlapEnd}:00`,
                };
                break;
              }
            }
          }
          if (overlappingSlot) break;
        }

        const repScore = normalizeReputationScore(
          candidate.reputation?.ratingAvg
            ? parseFloat(candidate.reputation.ratingAvg)
            : null,
          candidate.reputation?.ratingCount || 0
        );

        const freshness = 0.8;
        const fairnessPenalty = 0;

        const score = calculateMatchScore({
          similarity: bestSimilarity,
          timeOverlap,
          repScore,
          freshness,
          fairnessPenalty,
        });

        if (matchedSkills.length > 0 || score > 0.3) {
          scoredCandidates.push({
            profile: candidate,
            score,
            matchedSkills: Array.from(new Set(matchedSkills)),
            overlappingSlot,
            similarity: bestSimilarity,
          });
        }
      }

      scoredCandidates.sort((a, b) => b.score - a.score);

      const top5 = scoredCandidates.slice(0, 5);

      const recommendations: RecommendationResult[] = top5.map((c) => {
        const xai = generateXAIExplanation({
          matchedSkills: c.matchedSkills,
          overlappingSlot: c.overlappingSlot,
          reputation: {
            avg: c.profile.reputation?.ratingAvg
              ? parseFloat(c.profile.reputation.ratingAvg)
              : 0,
            count: c.profile.reputation?.ratingCount || 0,
          },
          similarity: c.similarity,
        });

        const preferredMode =
          c.profile.availability?.[0]?.mode || "ONLINE";

        return {
          profileId: c.profile.id,
          name: c.profile.displayName || "User",
          mode: preferredMode,
          reputation: {
            avg: c.profile.reputation?.ratingAvg
              ? parseFloat(c.profile.reputation.ratingAvg)
              : 0,
            count: c.profile.reputation?.ratingCount || 0,
          },
          matchedSkills: c.matchedSkills,
          xai,
        };
      });

      res.json(recommendations);
    } catch (error) {
      console.error("Matching error:", error);
      res.status(500).json({ ok: false, error: "Failed to get recommendations" });
    }
  });

  app.post("/api/matching/accept", authMiddleware, async (req, res) => {
    try {
      const { profileId } = req.body;
      if (!profileId) {
        return res.status(400).json({ ok: false, error: "profileId required" });
      }

      const targetProfile = await storage.getProfile(profileId);
      if (!targetProfile) {
        return res.status(404).json({ ok: false, error: "Profile not found" });
      }

      res.json({ ok: true, profileId });
    } catch (error) {
      console.error("Accept error:", error);
      res.status(500).json({ ok: false, error: "Failed to accept match" });
    }
  });

  app.post("/api/schedule", authMiddleware, async (req, res) => {
    try {
      const parsed = scheduleSessionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ ok: false, error: parsed.error.errors[0].message });
      }

      const { targetProfileId, date, from, to, mode, note, reminders } = parsed.data;

      const myProfile = await storage.getProfileByUserId(req.user!.id);
      if (!myProfile) {
        return res.status(404).json({ ok: false, error: "Your profile not found" });
      }

      const targetProfile = await storage.getProfile(targetProfileId);
      if (!targetProfile) {
        return res.status(404).json({ ok: false, error: "Target profile not found" });
      }

      const startDateTime = new Date(`${date}T${from}:00`);
      const endDateTime = new Date(`${date}T${to}:00`);

      const session = await storage.createSession({
        mentorProfileId: targetProfileId,
        learnerProfileId: myProfile.id,
        start: startDateTime,
        end: endDateTime,
        mode,
        note: note || null,
        location: null,
        status: "SCHEDULED",
      });

      if (reminders && reminders.length > 0) {
        console.log(`Reminders scheduled for session ${session.id}:`, reminders);
      }

      res.status(201).json({ ok: true, sessionId: session.id });
    } catch (error) {
      console.error("Schedule error:", error);
      res.status(500).json({ ok: false, error: "Failed to schedule session" });
    }
  });

  return httpServer;
}
