import bcrypt from "bcrypt";
import { storage } from "./storage";

export async function seedDatabase() {
  console.log("Seeding database...");

  const existingSkills = await storage.getAllSkills();
  if (existingSkills.length > 0) {
    console.log("Database already seeded, skipping...");
    return;
  }

  const skills = [
    { name: "Python Basics", taxonomyTag: "programming" },
    { name: "Intro to Python", taxonomyTag: "programming" },
    { name: "JavaScript Fundamentals", taxonomyTag: "programming" },
    { name: "React.js", taxonomyTag: "frontend" },
    { name: "Excel Pivot Tables", taxonomyTag: "productivity" },
    { name: "Data Analysis", taxonomyTag: "data" },
    { name: "Jupyter/Colab Intro", taxonomyTag: "data" },
    { name: "SQL Basics", taxonomyTag: "database" },
    { name: "Git & Version Control", taxonomyTag: "tools" },
    { name: "UI/UX Design", taxonomyTag: "design" },
    { name: "Machine Learning Intro", taxonomyTag: "ai" },
    { name: "Public Speaking", taxonomyTag: "soft-skills" },
  ];

  const createdSkills = await Promise.all(
    skills.map((skill) => storage.createSkill(skill))
  );

  const users = [
    {
      email: "ana@example.com",
      password: "password123",
      displayName: "Ana M.",
      bio: "Data scientist with 5 years of experience. Love teaching Python and machine learning concepts.",
      offered: [0, 6, 10],
      wanted: [3, 9],
      availability: [
        { weekday: 3, startTime: "19:00", endTime: "20:00", mode: "ONLINE" as const },
        { weekday: 5, startTime: "18:00", endTime: "19:00", mode: "ONLINE" as const },
      ],
      reputation: { avg: 4.6, count: 9 },
    },
    {
      email: "boris@example.com",
      password: "password123",
      displayName: "Boris K.",
      bio: "Frontend developer specializing in React. Eager to learn data analysis skills.",
      offered: [2, 3],
      wanted: [5, 7],
      availability: [
        { weekday: 2, startTime: "20:00", endTime: "21:00", mode: "ONLINE" as const },
        { weekday: 4, startTime: "19:00", endTime: "20:00", mode: "OFFLINE" as const, zoneHint: "Downtown" },
      ],
      reputation: { avg: 4.8, count: 12 },
    },
    {
      email: "carla@example.com",
      password: "password123",
      displayName: "Carla D.",
      bio: "Business analyst with strong Excel skills. Looking to transition into programming.",
      offered: [4, 5],
      wanted: [0, 2],
      availability: [
        { weekday: 1, startTime: "17:00", endTime: "18:00", mode: "ONLINE" as const },
        { weekday: 3, startTime: "18:00", endTime: "19:00", mode: "ONLINE" as const },
      ],
      reputation: { avg: 4.2, count: 5 },
    },
    {
      email: "david@example.com",
      password: "password123",
      displayName: "David L.",
      bio: "Full-stack developer and open source contributor. Happy to share knowledge about Git and SQL.",
      offered: [7, 8, 2],
      wanted: [10, 11],
      availability: [
        { weekday: 6, startTime: "10:00", endTime: "11:00", mode: "OFFLINE" as const, zoneHint: "Central Library" },
        { weekday: 7, startTime: "14:00", endTime: "15:00", mode: "ONLINE" as const },
      ],
      reputation: { avg: 4.9, count: 15 },
    },
    {
      email: "elena@example.com",
      password: "password123",
      displayName: "Elena S.",
      bio: "UX designer with a passion for creating intuitive interfaces. Also teach public speaking workshops.",
      offered: [9, 11],
      wanted: [3, 6],
      availability: [
        { weekday: 2, startTime: "19:00", endTime: "20:00", mode: "ONLINE" as const },
        { weekday: 4, startTime: "17:00", endTime: "18:00", mode: "OFFLINE" as const, zoneHint: "Co-working Space" },
      ],
      reputation: { avg: 4.7, count: 8 },
    },
  ];

  for (const userData of users) {
    const passHash = await bcrypt.hash(userData.password, 10);
    
    const user = await storage.createUser({
      email: userData.email,
      passHash,
      role: "USER",
    });

    const profile = await storage.createProfile({
      userId: user.id,
      displayName: userData.displayName,
      bio: userData.bio,
      visibility: "PUBLIC",
    });

    for (const skillIndex of userData.offered) {
      await storage.createProfileSkill({
        profileId: profile.id,
        skillId: createdSkills[skillIndex].id,
        level: Math.floor(Math.random() * 3) + 3,
        type: "OFFERED",
      });
    }

    for (const skillIndex of userData.wanted) {
      await storage.createProfileSkill({
        profileId: profile.id,
        skillId: createdSkills[skillIndex].id,
        level: 1,
        type: "WANTED",
      });
    }

    for (const avail of userData.availability) {
      await storage.createAvailability({
        profileId: profile.id,
        ...avail,
      });
    }

    await storage.createOrUpdateReputation({
      profileId: profile.id,
      ratingAvg: userData.reputation.avg.toString(),
      ratingCount: userData.reputation.count,
      noShowRate: "0.05",
    });
  }

  console.log("Seed data created successfully!");
  console.log(`Created ${createdSkills.length} skills`);
  console.log(`Created ${users.length} users with profiles`);
}
