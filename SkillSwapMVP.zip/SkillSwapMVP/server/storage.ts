import { randomUUID } from "crypto";
import type {
  User,
  InsertUser,
  Profile,
  InsertProfile,
  Skill,
  InsertSkill,
  ProfileSkill,
  InsertProfileSkill,
  Availability,
  InsertAvailability,
  Session,
  InsertSession,
  Feedback,
  InsertFeedback,
  Reputation,
  InsertReputation,
  ProfileWithDetails,
  UserWithProfile,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserWithProfile(id: string): Promise<UserWithProfile | undefined>;

  getProfile(id: string): Promise<Profile | undefined>;
  getProfileByUserId(userId: string): Promise<Profile | undefined>;
  getProfileWithDetails(profileId: string): Promise<ProfileWithDetails | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: string, updates: Partial<Profile>): Promise<Profile | undefined>;

  getAllSkills(): Promise<Skill[]>;
  getSkill(id: string): Promise<Skill | undefined>;
  createSkill(skill: InsertSkill): Promise<Skill>;

  getProfileSkills(profileId: string): Promise<(ProfileSkill & { skill: Skill })[]>;
  createProfileSkill(ps: InsertProfileSkill): Promise<ProfileSkill>;
  deleteProfileSkills(profileId: string, type?: "OFFERED" | "WANTED"): Promise<void>;

  getAvailability(profileId: string): Promise<Availability[]>;
  createAvailability(availability: InsertAvailability): Promise<Availability>;
  deleteAvailability(profileId: string): Promise<void>;

  getAllProfiles(): Promise<ProfileWithDetails[]>;
  getProfilesForMatching(excludeProfileId: string): Promise<ProfileWithDetails[]>;

  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, updates: Partial<Session>): Promise<Session | undefined>;

  getReputation(profileId: string): Promise<Reputation | undefined>;
  createOrUpdateReputation(rep: InsertReputation): Promise<Reputation>;

  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private profiles: Map<string, Profile> = new Map();
  private skills: Map<string, Skill> = new Map();
  private profileSkills: Map<string, ProfileSkill> = new Map();
  private availability: Map<string, Availability> = new Map();
  private sessions: Map<string, Session> = new Map();
  private feedback: Map<string, Feedback> = new Map();
  private reputation: Map<string, Reputation> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      id,
      email: insertUser.email,
      passHash: insertUser.passHash,
      role: insertUser.role || "USER",
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getUserWithProfile(id: string): Promise<UserWithProfile | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const profile = await this.getProfileByUserId(user.id);
    let profileWithDetails: ProfileWithDetails | null = null;

    if (profile) {
      const details = await this.getProfileWithDetails(profile.id);
      profileWithDetails = details || null;
    }

    return { ...user, profile: profileWithDetails };
  }

  async getProfile(id: string): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }

  async getProfileByUserId(userId: string): Promise<Profile | undefined> {
    return Array.from(this.profiles.values()).find(
      (profile) => profile.userId === userId
    );
  }

  async getProfileWithDetails(profileId: string): Promise<ProfileWithDetails | undefined> {
    const profile = await this.getProfile(profileId);
    if (!profile) return undefined;

    const allProfileSkills = await this.getProfileSkills(profileId);
    const offeredSkills = allProfileSkills.filter((ps) => ps.type === "OFFERED");
    const wantedSkills = allProfileSkills.filter((ps) => ps.type === "WANTED");
    const availability = await this.getAvailability(profileId);
    const rep = await this.getReputation(profileId);

    return {
      ...profile,
      offeredSkills,
      wantedSkills,
      availability,
      reputation: rep || null,
    };
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = randomUUID();
    const profile: Profile = {
      id,
      userId: insertProfile.userId,
      displayName: insertProfile.displayName || null,
      bio: insertProfile.bio || null,
      visibility: insertProfile.visibility || "PUBLIC",
      createdAt: new Date(),
    };
    this.profiles.set(id, profile);
    return profile;
  }

  async updateProfile(id: string, updates: Partial<Profile>): Promise<Profile | undefined> {
    const profile = await this.getProfile(id);
    if (!profile) return undefined;

    const updated = { ...profile, ...updates };
    this.profiles.set(id, updated);
    return updated;
  }

  async getAllSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async getSkill(id: string): Promise<Skill | undefined> {
    return this.skills.get(id);
  }

  async createSkill(insertSkill: InsertSkill): Promise<Skill> {
    const id = randomUUID();
    const skill: Skill = {
      id,
      name: insertSkill.name,
      taxonomyTag: insertSkill.taxonomyTag || null,
    };
    this.skills.set(id, skill);
    return skill;
  }

  async getProfileSkills(profileId: string): Promise<(ProfileSkill & { skill: Skill })[]> {
    const skills = Array.from(this.profileSkills.values()).filter(
      (ps) => ps.profileId === profileId
    );

    return Promise.all(
      skills.map(async (ps) => {
        const skill = await this.getSkill(ps.skillId);
        return { ...ps, skill: skill! };
      })
    );
  }

  async createProfileSkill(insertPs: InsertProfileSkill): Promise<ProfileSkill> {
    const id = randomUUID();
    const ps: ProfileSkill = {
      id,
      profileId: insertPs.profileId,
      skillId: insertPs.skillId,
      level: insertPs.level || 1,
      type: insertPs.type,
    };
    this.profileSkills.set(id, ps);
    return ps;
  }

  async deleteProfileSkills(profileId: string, type?: "OFFERED" | "WANTED"): Promise<void> {
    const toDelete = Array.from(this.profileSkills.entries()).filter(
      ([, ps]) => ps.profileId === profileId && (!type || ps.type === type)
    );
    toDelete.forEach(([id]) => this.profileSkills.delete(id));
  }

  async getAvailability(profileId: string): Promise<Availability[]> {
    return Array.from(this.availability.values()).filter(
      (a) => a.profileId === profileId
    );
  }

  async createAvailability(insertAvail: InsertAvailability): Promise<Availability> {
    const id = randomUUID();
    const avail: Availability = {
      id,
      profileId: insertAvail.profileId,
      weekday: insertAvail.weekday,
      startTime: insertAvail.startTime,
      endTime: insertAvail.endTime,
      mode: insertAvail.mode,
      zoneHint: insertAvail.zoneHint || null,
    };
    this.availability.set(id, avail);
    return avail;
  }

  async deleteAvailability(profileId: string): Promise<void> {
    const toDelete = Array.from(this.availability.entries()).filter(
      ([, a]) => a.profileId === profileId
    );
    toDelete.forEach(([id]) => this.availability.delete(id));
  }

  async getAllProfiles(): Promise<ProfileWithDetails[]> {
    const profiles = Array.from(this.profiles.values());
    return Promise.all(
      profiles.map((p) => this.getProfileWithDetails(p.id) as Promise<ProfileWithDetails>)
    );
  }

  async getProfilesForMatching(excludeProfileId: string): Promise<ProfileWithDetails[]> {
    const profiles = Array.from(this.profiles.values()).filter(
      (p) => p.id !== excludeProfileId && p.visibility !== "PRIVATE"
    );
    return Promise.all(
      profiles.map((p) => this.getProfileWithDetails(p.id) as Promise<ProfileWithDetails>)
    );
  }

  async getSession(id: string): Promise<Session | undefined> {
    return this.sessions.get(id);
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      id,
      mentorProfileId: insertSession.mentorProfileId,
      learnerProfileId: insertSession.learnerProfileId,
      start: new Date(insertSession.start),
      end: new Date(insertSession.end),
      location: insertSession.location || null,
      mode: insertSession.mode,
      note: insertSession.note || null,
      status: insertSession.status || "SCHEDULED",
      createdAt: new Date(),
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSession(id: string, updates: Partial<Session>): Promise<Session | undefined> {
    const session = await this.getSession(id);
    if (!session) return undefined;

    const updated = { ...session, ...updates };
    this.sessions.set(id, updated);
    return updated;
  }

  async getReputation(profileId: string): Promise<Reputation | undefined> {
    return this.reputation.get(profileId);
  }

  async createOrUpdateReputation(rep: InsertReputation): Promise<Reputation> {
    const existing = await this.getReputation(rep.profileId);
    const reputation: Reputation = {
      profileId: rep.profileId,
      ratingAvg: rep.ratingAvg || existing?.ratingAvg || null,
      ratingCount: rep.ratingCount ?? existing?.ratingCount ?? 0,
      noShowRate: rep.noShowRate || existing?.noShowRate || null,
      updatedAt: new Date(),
    };
    this.reputation.set(rep.profileId, reputation);
    return reputation;
  }

  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const id = randomUUID();
    const fb: Feedback = {
      id,
      sessionId: insertFeedback.sessionId,
      raterProfileId: insertFeedback.raterProfileId,
      targetProfileId: insertFeedback.targetProfileId,
      rating: insertFeedback.rating,
      comment: insertFeedback.comment || null,
      reliabilityScore: insertFeedback.reliabilityScore || null,
      createdAt: new Date(),
    };
    this.feedback.set(id, fb);
    return fb;
  }
}

export const storage = new MemStorage();
